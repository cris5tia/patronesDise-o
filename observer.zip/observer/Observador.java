public interface Observador {
    void actualizar();
}
